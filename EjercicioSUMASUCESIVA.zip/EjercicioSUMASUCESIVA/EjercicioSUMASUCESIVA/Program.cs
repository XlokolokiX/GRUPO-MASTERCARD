﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioSUMASUCESIVA
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese un primer numero:");
            int n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese un segundo numero:");
            int n2 = Convert.ToInt32(Console.ReadLine());

            int res=0;

            for (int i = 0; i<n2; i++)
            {

                res += n1;
   
            }

            Console.WriteLine(".........................................");
            Console.WriteLine($"Multiplicacion por suma sucesiva: {res}");
            Console.WriteLine(".........................................");
            Console.ReadKey();
        }
    }
}
