using System;

namespace GestionDeProyectosPM
{
    public struct UserStory
    {
        public String how;
        public String want;
        public String to;
    }
}