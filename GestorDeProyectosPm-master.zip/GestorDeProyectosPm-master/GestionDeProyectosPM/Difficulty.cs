using System;

namespace GestionDeProyectosPM
{
    public enum Difficulty
    {
        easy,
        compliacted,
        superComplicated
    }
}