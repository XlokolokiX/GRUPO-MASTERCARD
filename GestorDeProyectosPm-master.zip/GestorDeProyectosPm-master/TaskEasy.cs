﻿using System;

public class TaskEasy : Task
{
	public Task()
	{
	}
}
