﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Globalization;

namespace ProblemaTiempo
{
    class Program
    {
        static void Main(string[] args)
        {
            CultureInfo cultura = CultureInfo.CurrentCulture;

            Console.WriteLine(cultura.Name);
            Console.WriteLine("-------------------------------------------------------");

            DateTime Tiempo1 = new DateTime(2020, 08, 12);
            DateTime Tiempo2 = new DateTime(2020, 07, 12);


            DateTimeFormatInfo asda = cultura.DateTimeFormat;
            int diferencia = Tiempo1.Subtract(Tiempo2).Days;
            int diferenciaS = diferencia / 7;

            Console.WriteLine($"{asda.GetDayName(Tiempo1.DayOfWeek)} {Tiempo1.Day} de {asda.GetMonthName(Tiempo1.Month)} del año {Tiempo1.Year}");
            Console.WriteLine($"{asda.GetDayName(Tiempo2.DayOfWeek)} {Tiempo2.Day} de {asda.GetMonthName(Tiempo2.Month)} del año {Tiempo2.Year}");
            Console.WriteLine("-------------------------------------------------------");
            Console.WriteLine($"Dias de diferencia: {diferencia}");
            Console.WriteLine($"Semanas de diferencia: {diferenciaS}");
            Console.WriteLine("-------------------------------------------------------");

            Console.ReadKey();
        }
    }
}
