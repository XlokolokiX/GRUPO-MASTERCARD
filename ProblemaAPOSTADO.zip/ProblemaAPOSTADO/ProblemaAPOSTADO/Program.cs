﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProblemaAPOSTADO
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bienvenido al casino mas CAPOMAFIA del conglomerado");
            Jugador<string, int> apostadores = new Jugador<string, int>();

            while (true)
            {
                Console.WriteLine("Haga su jugada pibe (tenes que poner asi cabeza (NOMBRE)/(NUMERO)) para jugar escribi tirar master");
                string n = (Console.ReadLine());
                if (n == "tirar")
                    break;
                int Napostado = int.Parse(n.Split('/')[1]);
                if (Napostado > 36)
                {
                    Console.WriteLine("ESTAS RE LOCO MAN ELEJI UNO MAS CHIQUITO");
                }
                else if (Napostado < 0)
                {
                    Console.WriteLine("POR QUE NO ME REGALAS NOMAS LA PLATA");
                }
                else
                {
                        apostadores.Add(n.Split('/')[0], Napostado);
                }
            }

            //Metodo de random
            var R = new Random();

            int RULETA = R.Next(0, 36);
            Console.WriteLine("............................................");
            Console.WriteLine($" LA RULETITA DE LO DIOSE DA:{RULETA}");
            Console.WriteLine("............................................");
            for (int i = 0; i < apostadores.name.Count; i++)
            {
                if (apostadores.num[i] == RULETA)
                    Console.WriteLine($"Gano el tipaso {apostadores.name[i]}");
            }

            for (int i = 0; i < apostadores.name.Count; i++)
            {
                if (!(apostadores.num[i] == RULETA))
                    Console.WriteLine($"PERDIERON; {apostadores.name[i]}");
            }

            Console.ReadKey();
        }
    }
}
