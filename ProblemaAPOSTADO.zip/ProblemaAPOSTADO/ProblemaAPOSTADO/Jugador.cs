﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProblemaAPOSTADO
{
    class Jugador<Tname, Tnum>
    {
        public List<Tname> name = new List<Tname>();
        public List<Tnum> num = new List<Tnum>();



        public void Add(Tname a, Tnum b)
        {
            name.Add(a);
            num.Add(b);
        }
    }
}
