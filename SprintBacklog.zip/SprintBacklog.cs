using System;
using System.Collections.Generic;    

namespace EjercicioPM
{
    public class SprintBacklog
    {
        private List<Tareas> _tareas;
        public SprintBacklog(){
            _tareas = new List<Tareas>();
        }

        public float getHoras(){
            float _horas = 0;
            foreach (var tarea in _tareas){
                _horas += tarea.getHoras();
            }
            return _horas;
        }

    }
}