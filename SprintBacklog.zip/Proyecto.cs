using System;


namespace EjercicioPM
{
    class Proyecto
    {
        int HorasPorProyecto;

        public int HorasProyecto { get; set; }
        

        }
    }
}
