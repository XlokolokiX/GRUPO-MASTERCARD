using System;


namespace EjercicioPM
{
    class Tareas
    {
        public String Descripcion{ get; set;}
        public int Estimacion {get; set;}
        public String Dificultad {get; set;}


        public float getHoras(){
            switch(Dificultad){
                case "facil":
                    return Estimacion;
                case "complicada":
                    return Estimacion * 1.20F;
                case "super complicada":
                    return Estimacion * 1.50F;
                default:
                    return Estimacion;
            } 
        }
    }
}